// Shared settings: defaults, limits and the list of controls shown in "Customize".
// Loaded by the popup, the bridge and the audio engine so they always agree.
(() => {
  const DEFAULTS = {
    enabled: true,
    gainDb: 8,            // main loudness boost
    limiterDb: -3,        // hard ceiling, protects against distortion
    bassDb: 0,
    presenceDb: 2,        // makes speech clearer
    trebleDb: 0,
    hpFreq: 80,           // cuts rumble below this (Hz)
    gateDb: -90,          // -90 = noise gate off
    compThreshold: -28,
    compRatio: 6,
    compAttack: 5,        // ms
    compRelease: 150,     // ms
    compKnee: 20,
    browserAutoVolume: false,  // let Chrome's own auto-volume run (usually fights the boost)
    noiseSuppression: true,
    echoCancellation: true
  };

  // Presets used by the Simple tab (values are dB of boost)
  const PRESETS = [
    { id: 'normal', label: 'Normal', gainDb: 0 },
    { id: 'louder', label: 'Louder', gainDb: 8 },
    { id: 'loud',   label: 'Loud',   gainDb: 16 },
    { id: 'max',    label: 'Max',    gainDb: 24 }
  ];

  // Customize controls. type: 'range' | 'toggle'
  const GROUPS = [
    { title: 'Loudness', items: [
      { key: 'gainDb', label: 'Boost', unit: ' dB', min: 0, max: 24, step: 1,
        hint: 'How much louder your voice is. Higher = louder, but also boosts background noise.' },
      { key: 'limiterDb', label: 'Safety ceiling', unit: ' dB', min: -12, max: 0, step: 1,
        hint: 'A wall your voice can never go above. Lower = safer, cleaner, a bit quieter.' }
    ]},
    { title: 'Tone', items: [
      { key: 'bassDb', label: 'Bass', unit: ' dB', min: -12, max: 12, step: 1,
        hint: 'Adds or removes low, deep sound.' },
      { key: 'presenceDb', label: 'Clarity', unit: ' dB', min: -12, max: 12, step: 1,
        hint: 'Makes words sharper and easier to understand.' },
      { key: 'trebleDb', label: 'Treble', unit: ' dB', min: -12, max: 12, step: 1,
        hint: 'Adds or removes high, airy sound.' }
    ]},
    { title: 'Clean-up', items: [
      { key: 'hpFreq', label: 'Rumble cut', unit: ' Hz', min: 20, max: 400, step: 10,
        hint: 'Removes low hum, desk bumps and wind. 80 is a good default.' },
      { key: 'gateDb', label: 'Noise gate', unit: ' dB', min: -90, max: -30, step: 1, offAt: -90,
        hint: 'Silences the mic when you are not talking. Move right to cut more noise. Far left = off.' }
    ]},
    { title: 'Compressor (evens out volume)', items: [
      { key: 'compThreshold', label: 'Threshold', unit: ' dB', min: -60, max: 0, step: 1,
        hint: 'Sounds louder than this get squeezed down.' },
      { key: 'compRatio', label: 'Ratio', unit: ':1', min: 1, max: 20, step: 1,
        hint: 'How hard loud sounds get squeezed. 1 = off.' },
      { key: 'compAttack', label: 'Attack', unit: ' ms', min: 1, max: 100, step: 1,
        hint: 'How fast the squeeze starts.' },
      { key: 'compRelease', label: 'Release', unit: ' ms', min: 20, max: 1000, step: 10,
        hint: 'How fast it lets go.' },
      { key: 'compKnee', label: 'Softness', unit: ' dB', min: 0, max: 40, step: 1,
        hint: 'Higher = smoother, less noticeable squeeze.' }
    ]},
    { title: 'Browser', note: 'These apply the next time a call starts.', items: [
      { key: 'echoCancellation', label: 'Echo cancel', type: 'toggle',
        hint: 'Stops your speakers being picked up by the mic. Keep on unless you wear headphones.' },
      { key: 'noiseSuppression', label: 'Noise suppression', type: 'toggle',
        hint: "Chrome's built-in background noise remover." },
      { key: 'browserAutoVolume', label: 'Browser auto-volume', type: 'toggle',
        hint: "Chrome's own auto-volume. Usually fights the boost, so keep it off." }
    ]}
  ];

  const LIMITS = {};
  for (const g of GROUPS) for (const it of g.items) {
    if (it.type !== 'toggle') LIMITS[it.key] = [it.min, it.max];
  }

  function sanitize(input) {
    const out = { ...DEFAULTS };
    const src = input && typeof input === 'object' ? input : {};
    for (const k of Object.keys(DEFAULTS)) {
      if (!(k in src)) continue;
      if (typeof DEFAULTS[k] === 'boolean') out[k] = Boolean(src[k]);
      else {
        const n = Number(src[k]);
        if (Number.isFinite(n)) {
          const [lo, hi] = LIMITS[k] || [-Infinity, Infinity];
          out[k] = Math.min(hi, Math.max(lo, n));
        }
      }
    }
    return out;
  }

  globalThis.LUCHI_CFG = { KEY: 'luchiMicConfig', DEFAULTS, PRESETS, GROUPS, sanitize };
})();
