// Erebus bridge. Passes your saved settings to the audio engine,
// and passes the live level meter back to the popup. Nothing leaves your computer.
(() => {
  const C = globalThis.LUCHI_CFG;
  const TO_PAGE = 'luchi-mic-bridge';
  const FROM_PAGE = 'luchi-mic-engine';
  let cfg = { ...C.DEFAULTS };

  const push = () => window.postMessage({ source: TO_PAGE, type: 'config', payload: cfg }, '*');

  function load() {
    try {
      chrome.storage.local.get(C.KEY, (res) => {
        if (chrome.runtime.lastError) return;
        cfg = C.sanitize(res && res[C.KEY]);
        push();
      });
    } catch (_) {}
  }
  load();

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[C.KEY]) {
        cfg = C.sanitize(changes[C.KEY].newValue);
        push();
      }
    });
  } catch (_) {}

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.source !== FROM_PAGE) return;
    if (d.type === 'ready') { push(); return; }
    if (d.type === 'status') {
      try {
        chrome.runtime.sendMessage(
          { type: 'LUCHI_STATUS', active: !!d.active, level: Number(d.level) || -100, limiting: !!d.limiting },
          () => void chrome.runtime.lastError  // popup closed: ignore
        );
      } catch (_) {}
    }
  });
})();
