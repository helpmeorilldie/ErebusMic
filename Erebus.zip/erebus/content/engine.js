// Erebus audio engine. Runs inside the WhatsApp Web page.
// It wraps getUserMedia so your mic goes through a small audio chain before WhatsApp sends it:
//   mic -> rumble cut -> noise gate -> boost -> tone -> compressor -> safety ceiling (soft clip) -> WhatsApp
(() => {
  if (window.__luchiMicEngine) return;
  window.__luchiMicEngine = true;

  const C = globalThis.LUCHI_CFG;
  const TO_PAGE = 'luchi-mic-engine';
  const FROM_BRIDGE = 'luchi-mic-bridge';
  const dbToLin = (db) => Math.pow(10, db / 20);

  let cfg = { ...C.DEFAULTS };
  let gotConfig = false;
  let resolveReady;
  const ready = new Promise((r) => { resolveReady = r; });

  const pipes = new Set();
  let ctx = null;

  // ---- settings from the bridge ----
  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.source !== FROM_BRIDGE || d.type !== 'config') return;
    cfg = C.sanitize(d.payload);
    gotConfig = true;
    resolveReady();
    for (const p of pipes) p.apply();
  });
  window.postMessage({ source: TO_PAGE, type: 'ready' }, '*');

  // ---- audio helpers ----
  function getCtx() {
    if (!ctx || ctx.state === 'closed') {
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC({ latencyHint: 'interactive' });
    }
    if (ctx.state !== 'running') ctx.resume().catch(() => {});
    return ctx;
  }
  ['click', 'keydown', 'pointerdown'].forEach((ev) =>
    window.addEventListener(ev, () => { if (ctx && ctx.state === 'suspended' && pipes.size) ctx.resume().catch(() => {}); }, true));

  // Safety ceiling: samples are left alone below 85% of the ceiling, then gently rounded off
  // so the output can never go above it. Input is scaled by 1/4 first so big boosts are caught too.
  function ceilingCurve(ceilDb) {
    const n = 8192, c = new Float32Array(n), ceil = dbToLin(ceilDb), k = ceil * 0.85;
    for (let i = 0; i < n; i++) {
      const x = ((i / (n - 1)) * 2 - 1) * 4, a = Math.abs(x);
      c[i] = a < k ? x : Math.sign(x) * (k + (ceil - k) * Math.tanh((a - k) / (ceil - k)));
    }
    return c;
  }

  function rmsDb(an, buf) {
    an.getFloatTimeDomainData(buf);
    let s = 0;
    for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i];
    return 10 * Math.log10(s / buf.length + 1e-12);
  }
  function peakDb(an, buf) {
    an.getFloatTimeDomainData(buf);
    let m = 0;
    for (let i = 0; i < buf.length; i++) { const v = Math.abs(buf[i]); if (v > m) m = v; }
    return 20 * Math.log10(m + 1e-9);
  }

  function biquad(ac, type, freq, q) {
    const f = ac.createBiquadFilter();
    f.type = type; f.frequency.value = freq;
    if (q != null) f.Q.value = q;
    return f;
  }

  // ---- one processing chain per mic track ----
  function buildPipe(inputTrack) {
    const ac = getCtx();
    const src = ac.createMediaStreamSource(new MediaStream([inputTrack]));
    const hp = biquad(ac, 'highpass', 80, 0.707);
    const gateTap = ac.createAnalyser(); gateTap.fftSize = 1024;
    const gate = ac.createGain();
    const boost = ac.createGain();
    const bass = biquad(ac, 'lowshelf', 200);
    const pres = biquad(ac, 'peaking', 3000, 1);
    const treb = biquad(ac, 'highshelf', 6000);
    const comp = ac.createDynamicsCompressor();
    const clipIn = ac.createGain(); clipIn.gain.value = 0.25;
    const clip = ac.createWaveShaper(); clip.oversample = '2x';
    let curveDb = null;
    const meter = ac.createAnalyser(); meter.fftSize = 1024;
    const dst = ac.createMediaStreamDestination();

    src.connect(hp);
    hp.connect(gateTap); hp.connect(gate);
    gate.connect(boost); boost.connect(bass); bass.connect(pres); pres.connect(treb);
    treb.connect(comp); comp.connect(clipIn); clipIn.connect(clip);
    clip.connect(meter); clip.connect(dst);

    const gateBuf = new Float32Array(gateTap.fftSize);
    const meterBuf = new Float32Array(meter.fftSize);
    let routedOn = null, gateOpenUntil = 0;

    const pipe = {
      meter, meterBuf,
      apply() {
        const t = ac.currentTime, k = 0.02;
        if (routedOn !== cfg.enabled) {          // switch between processed and untouched
          try { src.disconnect(); } catch (_) {}
          if (cfg.enabled) src.connect(hp);
          else { src.connect(dst); src.connect(meter); }
          routedOn = cfg.enabled;
        }
        hp.frequency.setTargetAtTime(cfg.hpFreq, t, k);
        boost.gain.setTargetAtTime(dbToLin(cfg.gainDb), t, k);
        bass.gain.setTargetAtTime(cfg.bassDb, t, k);
        pres.gain.setTargetAtTime(cfg.presenceDb, t, k);
        treb.gain.setTargetAtTime(cfg.trebleDb, t, k);
        comp.threshold.setTargetAtTime(cfg.compThreshold, t, k);
        comp.ratio.setTargetAtTime(cfg.compRatio, t, k);
        comp.knee.setTargetAtTime(cfg.compKnee, t, k);
        comp.attack.setTargetAtTime(cfg.compAttack / 1000, t, k);
        comp.release.setTargetAtTime(cfg.compRelease / 1000, t, k);
        if (curveDb !== cfg.limiterDb) { clip.curve = ceilingCurve(cfg.limiterDb); curveDb = cfg.limiterDb; }
        if (cfg.gateDb <= -90) gate.gain.setTargetAtTime(1, t, k);
      }
    };

    // Noise gate: quiet = close, speaking = open (with a short hold so words are not clipped)
    const gateTimer = setInterval(() => {
      if (!cfg.enabled || cfg.gateDb <= -90) return;
      const now = performance.now();
      if (rmsDb(gateTap, gateBuf) > cfg.gateDb) gateOpenUntil = now + 250;
      const open = now < gateOpenUntil;
      gate.gain.setTargetAtTime(open ? 1 : 0, ac.currentTime, open ? 0.01 : 0.06);
    }, 25);

    pipe.apply();
    pipe.dispose = () => {
      clearInterval(gateTimer);
      [src, hp, gateTap, gate, boost, bass, pres, treb, comp, clipIn, clip, meter].forEach((n) => { try { n.disconnect(); } catch (_) {} });
      pipes.delete(pipe);
      if (!pipes.size && ctx && ctx.state === 'running') ctx.suspend().catch(() => {});
    };
    pipe.track = dst.stream.getAudioTracks()[0];
    pipes.add(pipe);
    return pipe;
  }

  function processTrack(inputTrack) {
    const pipe = buildPipe(inputTrack);
    const out = pipe.track;
    const origStop = out.stop.bind(out);
    let done = false;
    const finish = () => { if (done) return; done = true; pipe.dispose(); };

    out.stop = () => { origStop(); try { inputTrack.stop(); } catch (_) {} finish(); };
    out.applyConstraints = (c) => inputTrack.applyConstraints(c);
    try { Object.defineProperty(out, 'label', { get: () => inputTrack.label }); } catch (_) {}
    inputTrack.addEventListener('ended', () => { finish(); out.dispatchEvent(new Event('ended')); });
    return out;
  }

  // ---- hook the microphone ----
  const md = navigator.mediaDevices;
  if (md && md.getUserMedia) {
    const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async function (constraints) {
      if (!gotConfig) await Promise.race([ready, new Promise((r) => setTimeout(r, 400))]);
      let c = constraints;
      if (c && c.audio && cfg.enabled) {
        const a = c.audio === true ? {} : { ...c.audio };
        a.echoCancellation = cfg.echoCancellation;
        a.noiseSuppression = cfg.noiseSuppression;
        a.autoGainControl = cfg.browserAutoVolume;
        c = { ...c, audio: a };
      }
      const stream = await orig(c);
      const audio = stream.getAudioTracks();
      if (!audio.length) return stream;
      try {
        return new MediaStream([...stream.getVideoTracks(), ...audio.map(processTrack)]);
      } catch (err) {
        console.warn('[Erebus] could not process audio, using normal mic', err);
        return stream;
      }
    };
  }

  // ---- tell the popup what is happening (live meter) ----
  setInterval(() => {
    let level = -100;
    for (const p of pipes) level = Math.max(level, peakDb(p.meter, p.meterBuf));
    const limiting = cfg.enabled && level > cfg.limiterDb - 1.5;
    window.postMessage({ source: TO_PAGE, type: 'status', active: pipes.size > 0, level, limiting }, '*');
  }, 120);
})();
