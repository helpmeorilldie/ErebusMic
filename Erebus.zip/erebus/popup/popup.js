(() => {
  const C = globalThis.LUCHI_CFG;
  const $ = (s, r = document) => r.querySelector(s);
  const store = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;

  let cfg = { ...C.DEFAULTS };
  let saveTimer = null;

  // ---------- storage ----------
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { if (store) store.set({ [C.KEY]: cfg }); }, 60);
  }
  function set(patch) { cfg = C.sanitize({ ...cfg, ...patch }); save(); render(); }

  // ---------- tabs ----------
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => { x.classList.toggle('active', x === t); x.setAttribute('aria-selected', x === t); });
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === 'tab-' + t.dataset.tab));
  }));

  // ---------- simple tab ----------
  const dbToPct = (db) => Math.round((db / 24) * 100);
  const pctToDb = (p) => Math.round((p / 100) * 24);

  $('#power').addEventListener('click', () => set({ enabled: !cfg.enabled }));
  $('#boost').addEventListener('input', (e) => set({ gainDb: pctToDb(Number(e.target.value)) }));

  const presetsEl = $('#presets');
  C.PRESETS.forEach((p) => {
    const b = document.createElement('button');
    b.className = 'preset'; b.dataset.id = p.id; b.textContent = p.label;
    b.addEventListener('click', () => set({ gainDb: p.gainDb, enabled: true }));
    presetsEl.appendChild(b);
  });

  // ---------- customize tab ----------
  const controls = {};
  const groupsEl = $('#groups');
  C.GROUPS.forEach((g) => {
    const card = document.createElement('div'); card.className = 'glass';
    card.innerHTML = `<div class="group-title"></div>`;
    $('.group-title', card).textContent = g.title;
    if (g.note) { const n = document.createElement('div'); n.className = 'group-note'; n.textContent = g.note; card.appendChild(n); }

    g.items.forEach((it) => {
      const row = document.createElement('div'); row.className = 'ctl';
      const id = 'c_' + it.key;
      const head = document.createElement('div'); head.className = 'ctl-head';
      const label = document.createElement('label'); label.htmlFor = id; label.textContent = it.label;
      head.appendChild(label);

      let input, valueEl = null;
      if (it.type === 'toggle') {
        const sw = document.createElement('span'); sw.className = 'switch';
        input = document.createElement('input'); input.type = 'checkbox'; input.id = id;
        sw.append(input, document.createElement('span'));
        input.addEventListener('change', () => set({ [it.key]: input.checked }));
        head.appendChild(sw);
      } else {
        valueEl = document.createElement('span'); valueEl.className = 'v';
        head.appendChild(valueEl);
      }
      const q = document.createElement('button'); q.className = 'q'; q.type = 'button'; q.textContent = '?'; q.setAttribute('aria-label', 'What does ' + it.label + ' do?');
      q.addEventListener('click', () => row.classList.toggle('open'));
      head.appendChild(q);
      row.appendChild(head);

      const hint = document.createElement('div'); hint.className = 'hint'; hint.textContent = it.hint; row.appendChild(hint);

      if (it.type !== 'toggle') {
        input = document.createElement('input'); input.type = 'range'; input.id = id;
        input.min = it.min; input.max = it.max; input.step = it.step;
        input.addEventListener('input', () => set({ [it.key]: Number(input.value) }));
        row.appendChild(input);
      }
      controls[it.key] = { it, input, valueEl };
      card.appendChild(row);
    });
    groupsEl.appendChild(card);
  });

  $('#reset').addEventListener('click', () => { cfg = { ...C.DEFAULTS }; save(); render(); });

  // ---------- render ----------
  function paintRange(el) {
    const p = ((el.value - el.min) / (el.max - el.min)) * 100;
    el.style.setProperty('--p', p + '%');
  }
  function render() {
    const on = cfg.enabled;
    const power = $('#power');
    power.classList.toggle('on', on); power.classList.toggle('off', !on);
    power.setAttribute('aria-pressed', on);
    $('#powerLabel').textContent = on ? 'On' : 'Off';
    $('#powerSub').textContent = on ? 'Your voice is being boosted' : 'Your normal mic is used';

    const pct = dbToPct(cfg.gainDb);
    const boost = $('#boost');
    boost.value = pct; paintRange(boost); boost.classList.toggle('hot', pct >= 80);
    $('#boostPct').textContent = pct + '%';
    $('#maxWarn').hidden = pct < 80;
    document.querySelectorAll('.preset').forEach((b) => {
      const p = C.PRESETS.find((x) => x.id === b.dataset.id);
      b.classList.toggle('active', p.gainDb === cfg.gainDb);
    });

    for (const k in controls) {
      const { it, input, valueEl } = controls[k];
      if (it.type === 'toggle') { input.checked = !!cfg[k]; continue; }
      if (document.activeElement !== input) input.value = cfg[k];
      paintRange(input);
      valueEl.textContent = it.offAt != null && cfg[k] <= it.offAt ? 'Off' : (cfg[k] > 0 && it.min < 0 ? '+' : '') + cfg[k] + it.unit;
    }
    renderChip();
  }

  // ---------- live status from the WhatsApp tab ----------
  let lastStatus = 0, active = false;
  let peakHold = -100, peakAt = 0;

  function renderChip() {
    const chip = $('#chip'), txt = $('#chipText');
    chip.classList.remove('live', 'off');
    if (!cfg.enabled) { chip.classList.add('off'); txt.textContent = 'Paused'; return; }
    const fresh = Date.now() - lastStatus < 1500;
    if (fresh && active) { chip.classList.add('live'); txt.textContent = 'Live on a WhatsApp call'; }
    else if (fresh) txt.textContent = 'WhatsApp open · waiting for a call';
    else txt.textContent = 'Open WhatsApp Web to start';
  }

  function paintMeter(db, limiting) {
    const pct = Math.max(0, Math.min(100, ((db + 60) / 60) * 100));
    $('#meterFill').style.width = pct + '%';
    const now = Date.now();
    if (db > peakHold || now - peakAt > 900) { peakHold = db; peakAt = now; }
    $('#meterPeak').style.left = Math.max(0, Math.min(100, ((peakHold + 60) / 60) * 100)) + '%';
    $('#meter').classList.toggle('hot', limiting || db > -2);
    $('#meterDb').textContent = db <= -99 ? '—' : Math.round(db) + ' dB';
    $('#meterHint').textContent = db <= -99 ? 'Start a call on WhatsApp Web and speak to see it move.'
      : (limiting || db > -2) ? 'Too hot. Lower the boost a little.' : 'Good. Keep the bar below the red.';
  }

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((m) => {
      if (!m || m.type !== 'LUCHI_STATUS') return;
      lastStatus = Date.now(); active = m.active;
      paintMeter(m.active ? m.level : -100, m.limiting);
      renderChip();
    });
  }
  setInterval(() => {
    if (Date.now() - lastStatus > 1500) paintMeter(-100, false);
    renderChip();
  }, 800);

  // ---------- password lock (a casual gate, not strong security) ----------
  // SHA-256 of the password, so the word itself is not sitting in the source.
  const PW_HASH = '99d9c0fe264ee585b67628f3c940e87a73f4cfbf347451f0dfaab153a5548d49';
  const sess = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.session) ? chrome.storage.session : null;
  async function sha(str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  function showApp() { $('#lock').hidden = true; $('#app').hidden = false; }
  $('#lockForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const ok = (await sha($('#pw').value.trim())) === PW_HASH;
    $('#lockErr').hidden = ok;
    if (ok) { if (sess) sess.set({ erebusUnlocked: true }); showApp(); }
    else { $('#pw').select(); }
  });
  // stays unlocked until the browser is closed
  if (sess) sess.get('erebusUnlocked', (r) => { if (r && r.erebusUnlocked) showApp(); });

  // ---------- init ----------
  if (store) {
    store.get(C.KEY, (res) => { cfg = C.sanitize(res && res[C.KEY]); render(); });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch[C.KEY]) { cfg = C.sanitize(ch[C.KEY].newValue); render(); }
    });
  } else render();
})();
